
package net.mcreator.railwaydecorations.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;

import net.mcreator.railwaydecorations.init.RailwaydecorationsModTabs;

public class RailwayCraftingItemItem extends Item {
	public RailwayCraftingItemItem() {
		super(new Item.Properties().tab(RailwaydecorationsModTabs.TAB_CREATIVE_TAB_RAILWAY_ITEMS).stacksTo(1).rarity(Rarity.COMMON));
	}

	@Override
	public boolean hasCraftingRemainingItem() {
		return true;
	}

	@Override
	public ItemStack getCraftingRemainingItem(ItemStack itemstack) {
		return new ItemStack(this);
	}
}
