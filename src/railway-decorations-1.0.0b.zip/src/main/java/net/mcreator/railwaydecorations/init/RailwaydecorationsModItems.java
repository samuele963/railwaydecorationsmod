
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.railwaydecorations.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.BlockItem;

import net.mcreator.railwaydecorations.item.RailwayCraftingItemItem;
import net.mcreator.railwaydecorations.RailwaydecorationsMod;

public class RailwaydecorationsModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, RailwaydecorationsMod.MODID);
	public static final RegistryObject<Item> SIGN_DEFAULT = block(RailwaydecorationsModBlocks.SIGN_DEFAULT, RailwaydecorationsModTabs.TAB_CREATIVE_TAB_RAILWAY_ITEMS);
	public static final RegistryObject<Item> RAILWAY_CRAFTING_ITEM = REGISTRY.register("railway_crafting_item", () -> new RailwayCraftingItemItem());
	public static final RegistryObject<Item> SIGN_DEFAULT_ALT = block(RailwaydecorationsModBlocks.SIGN_DEFAULT_ALT, RailwaydecorationsModTabs.TAB_CREATIVE_TAB_RAILWAY_ITEMS);
	public static final RegistryObject<Item> SIGN_EXIT = block(RailwaydecorationsModBlocks.SIGN_EXIT, RailwaydecorationsModTabs.TAB_CREATIVE_TAB_RAILWAY_ITEMS);
	public static final RegistryObject<Item> SIGN_EXIT_ALT = block(RailwaydecorationsModBlocks.SIGN_EXIT_ALT, RailwaydecorationsModTabs.TAB_CREATIVE_TAB_RAILWAY_ITEMS);
	public static final RegistryObject<Item> SIGN_EXIT_BIG = block(RailwaydecorationsModBlocks.SIGN_EXIT_BIG, RailwaydecorationsModTabs.TAB_CREATIVE_TAB_RAILWAY_ITEMS);
	public static final RegistryObject<Item> SIGN_ZONE_A = block(RailwaydecorationsModBlocks.SIGN_ZONE_A, RailwaydecorationsModTabs.TAB_CREATIVE_TAB_RAILWAY_ITEMS);
	public static final RegistryObject<Item> SIGN_ZONE_B = block(RailwaydecorationsModBlocks.SIGN_ZONE_B, RailwaydecorationsModTabs.TAB_CREATIVE_TAB_RAILWAY_ITEMS);
	public static final RegistryObject<Item> SIGN_ZONE_C = block(RailwaydecorationsModBlocks.SIGN_ZONE_C, RailwaydecorationsModTabs.TAB_CREATIVE_TAB_RAILWAY_ITEMS);
	public static final RegistryObject<Item> SIGN_ZONE_D = block(RailwaydecorationsModBlocks.SIGN_ZONE_D, RailwaydecorationsModTabs.TAB_CREATIVE_TAB_RAILWAY_ITEMS);
	public static final RegistryObject<Item> SIGN_ZONE_A_ALT = block(RailwaydecorationsModBlocks.SIGN_ZONE_A_ALT, RailwaydecorationsModTabs.TAB_CREATIVE_TAB_RAILWAY_ITEMS);
	public static final RegistryObject<Item> SIGN_ZONE_B_ALT = block(RailwaydecorationsModBlocks.SIGN_ZONE_B_ALT, RailwaydecorationsModTabs.TAB_CREATIVE_TAB_RAILWAY_ITEMS);
	public static final RegistryObject<Item> SIGN_ZONE_C_ALT = block(RailwaydecorationsModBlocks.SIGN_ZONE_C_ALT, RailwaydecorationsModTabs.TAB_CREATIVE_TAB_RAILWAY_ITEMS);
	public static final RegistryObject<Item> SIGN_ZONE_D_ALT = block(RailwaydecorationsModBlocks.SIGN_ZONE_D_ALT, RailwaydecorationsModTabs.TAB_CREATIVE_TAB_RAILWAY_ITEMS);
	public static final RegistryObject<Item> SIGN_TICKETS = block(RailwaydecorationsModBlocks.SIGN_TICKETS, RailwaydecorationsModTabs.TAB_CREATIVE_TAB_RAILWAY_ITEMS);
	public static final RegistryObject<Item> SIGN_ZONE_AB = block(RailwaydecorationsModBlocks.SIGN_ZONE_AB, RailwaydecorationsModTabs.TAB_CREATIVE_TAB_RAILWAY_ITEMS);
	public static final RegistryObject<Item> SIGN_ZONE_CD = block(RailwaydecorationsModBlocks.SIGN_ZONE_CD, RailwaydecorationsModTabs.TAB_CREATIVE_TAB_RAILWAY_ITEMS);
	public static final RegistryObject<Item> SIGN_ZONE_ABCD = block(RailwaydecorationsModBlocks.SIGN_ZONE_ABCD, RailwaydecorationsModTabs.TAB_CREATIVE_TAB_RAILWAY_ITEMS);
	public static final RegistryObject<Item> SIGN_PLATFORM_1 = block(RailwaydecorationsModBlocks.SIGN_PLATFORM_1, RailwaydecorationsModTabs.TAB_CREATIVE_TAB_RAILWAY_ITEMS);
	public static final RegistryObject<Item> SIGN_PLATFORM_2 = block(RailwaydecorationsModBlocks.SIGN_PLATFORM_2, RailwaydecorationsModTabs.TAB_CREATIVE_TAB_RAILWAY_ITEMS);
	public static final RegistryObject<Item> SIGN_PLATFORM_3 = block(RailwaydecorationsModBlocks.SIGN_PLATFORM_3, RailwaydecorationsModTabs.TAB_CREATIVE_TAB_RAILWAY_ITEMS);
	public static final RegistryObject<Item> SIGN_PLATFORM_4 = block(RailwaydecorationsModBlocks.SIGN_PLATFORM_4, RailwaydecorationsModTabs.TAB_CREATIVE_TAB_RAILWAY_ITEMS);
	public static final RegistryObject<Item> SIGN_PLATFORM_5 = block(RailwaydecorationsModBlocks.SIGN_PLATFORM_5, RailwaydecorationsModTabs.TAB_CREATIVE_TAB_RAILWAY_ITEMS);
	public static final RegistryObject<Item> SIGN_PLATFORM_6 = block(RailwaydecorationsModBlocks.SIGN_PLATFORM_6, RailwaydecorationsModTabs.TAB_CREATIVE_TAB_RAILWAY_ITEMS);
	public static final RegistryObject<Item> SIGN_PLATFORM_7 = block(RailwaydecorationsModBlocks.SIGN_PLATFORM_7, RailwaydecorationsModTabs.TAB_CREATIVE_TAB_RAILWAY_ITEMS);
	public static final RegistryObject<Item> SIGN_PLATFORM_8 = block(RailwaydecorationsModBlocks.SIGN_PLATFORM_8, RailwaydecorationsModTabs.TAB_CREATIVE_TAB_RAILWAY_ITEMS);
	public static final RegistryObject<Item> SIGN_PLATFORM_9 = block(RailwaydecorationsModBlocks.SIGN_PLATFORM_9, RailwaydecorationsModTabs.TAB_CREATIVE_TAB_RAILWAY_ITEMS);
	public static final RegistryObject<Item> SIGN_PLATFORM_10 = block(RailwaydecorationsModBlocks.SIGN_PLATFORM_10, RailwaydecorationsModTabs.TAB_CREATIVE_TAB_RAILWAY_ITEMS);
	public static final RegistryObject<Item> SIGN_PLATFORM_11 = block(RailwaydecorationsModBlocks.SIGN_PLATFORM_11, RailwaydecorationsModTabs.TAB_CREATIVE_TAB_RAILWAY_ITEMS);
	public static final RegistryObject<Item> SIGN_PLATFORM_12 = block(RailwaydecorationsModBlocks.SIGN_PLATFORM_12, RailwaydecorationsModTabs.TAB_CREATIVE_TAB_RAILWAY_ITEMS);
	public static final RegistryObject<Item> SIGN_STAIRS_ASCENDING = block(RailwaydecorationsModBlocks.SIGN_STAIRS_ASCENDING, RailwaydecorationsModTabs.TAB_CREATIVE_TAB_RAILWAY_ITEMS);
	public static final RegistryObject<Item> SIGN_STAIRS_DESCENDING = block(RailwaydecorationsModBlocks.SIGN_STAIRS_DESCENDING, RailwaydecorationsModTabs.TAB_CREATIVE_TAB_RAILWAY_ITEMS);
	public static final RegistryObject<Item> SIGN_EXIT_ARROW = block(RailwaydecorationsModBlocks.SIGN_EXIT_ARROW, RailwaydecorationsModTabs.TAB_CREATIVE_TAB_RAILWAY_ITEMS);
	public static final RegistryObject<Item> SIGN_TICKETS_ARROW_1 = block(RailwaydecorationsModBlocks.SIGN_TICKETS_ARROW_1, RailwaydecorationsModTabs.TAB_CREATIVE_TAB_RAILWAY_ITEMS);
	public static final RegistryObject<Item> SIGN_TICKETS_ARROW_2 = block(RailwaydecorationsModBlocks.SIGN_TICKETS_ARROW_2, RailwaydecorationsModTabs.TAB_CREATIVE_TAB_RAILWAY_ITEMS);
	public static final RegistryObject<Item> SIGN_RESTAURANT = block(RailwaydecorationsModBlocks.SIGN_RESTAURANT, RailwaydecorationsModTabs.TAB_CREATIVE_TAB_RAILWAY_ITEMS);
	public static final RegistryObject<Item> SIGN_CAFE = block(RailwaydecorationsModBlocks.SIGN_CAFE, RailwaydecorationsModTabs.TAB_CREATIVE_TAB_RAILWAY_ITEMS);
	public static final RegistryObject<Item> SIGN_NO_ENTRY = block(RailwaydecorationsModBlocks.SIGN_NO_ENTRY, RailwaydecorationsModTabs.TAB_CREATIVE_TAB_RAILWAY_ITEMS);

	private static RegistryObject<Item> block(RegistryObject<Block> block, CreativeModeTab tab) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties().tab(tab)));
	}
}
