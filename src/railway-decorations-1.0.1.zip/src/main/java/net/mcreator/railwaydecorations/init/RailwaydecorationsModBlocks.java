
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.railwaydecorations.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.railwaydecorations.block.SignZoneDBlock;
import net.mcreator.railwaydecorations.block.SignZoneDAltBlock;
import net.mcreator.railwaydecorations.block.SignZoneCDBlock;
import net.mcreator.railwaydecorations.block.SignZoneCBlock;
import net.mcreator.railwaydecorations.block.SignZoneCAltBlock;
import net.mcreator.railwaydecorations.block.SignZoneBBlock;
import net.mcreator.railwaydecorations.block.SignZoneBAltBlock;
import net.mcreator.railwaydecorations.block.SignZoneABlock;
import net.mcreator.railwaydecorations.block.SignZoneABCDBlock;
import net.mcreator.railwaydecorations.block.SignZoneABBlock;
import net.mcreator.railwaydecorations.block.SignZoneAAltBlock;
import net.mcreator.railwaydecorations.block.SignTicketsBlock;
import net.mcreator.railwaydecorations.block.SignTicketsBigBlock;
import net.mcreator.railwaydecorations.block.SignTicketsArrow2Block;
import net.mcreator.railwaydecorations.block.SignTicketsArrow1Block;
import net.mcreator.railwaydecorations.block.SignStairsDescendingBlock;
import net.mcreator.railwaydecorations.block.SignStairsAscendingBlock;
import net.mcreator.railwaydecorations.block.SignRestaurantBlock;
import net.mcreator.railwaydecorations.block.SignPlatform9Block;
import net.mcreator.railwaydecorations.block.SignPlatform8Block;
import net.mcreator.railwaydecorations.block.SignPlatform7Block;
import net.mcreator.railwaydecorations.block.SignPlatform6Block;
import net.mcreator.railwaydecorations.block.SignPlatform5Block;
import net.mcreator.railwaydecorations.block.SignPlatform4Block;
import net.mcreator.railwaydecorations.block.SignPlatform3Block;
import net.mcreator.railwaydecorations.block.SignPlatform2Block;
import net.mcreator.railwaydecorations.block.SignPlatform1Block;
import net.mcreator.railwaydecorations.block.SignPlatform12Block;
import net.mcreator.railwaydecorations.block.SignPlatform11Block;
import net.mcreator.railwaydecorations.block.SignPlatform10Block;
import net.mcreator.railwaydecorations.block.SignNoEntryBlock;
import net.mcreator.railwaydecorations.block.SignMetroEntranceBlock;
import net.mcreator.railwaydecorations.block.SignLineB2Block;
import net.mcreator.railwaydecorations.block.SignLineB1Block;
import net.mcreator.railwaydecorations.block.SignLineA2Block;
import net.mcreator.railwaydecorations.block.SignLineA1Block;
import net.mcreator.railwaydecorations.block.SignExitBlock;
import net.mcreator.railwaydecorations.block.SignExitBigBlock;
import net.mcreator.railwaydecorations.block.SignExitArrowBlock;
import net.mcreator.railwaydecorations.block.SignExitAltBlock;
import net.mcreator.railwaydecorations.block.SignDefaultBlock;
import net.mcreator.railwaydecorations.block.SignDefaultAltBlock;
import net.mcreator.railwaydecorations.block.SignCafeBlock;
import net.mcreator.railwaydecorations.RailwaydecorationsMod;

public class RailwaydecorationsModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, RailwaydecorationsMod.MODID);
	public static final RegistryObject<Block> SIGN_DEFAULT = REGISTRY.register("sign_default", () -> new SignDefaultBlock());
	public static final RegistryObject<Block> SIGN_DEFAULT_ALT = REGISTRY.register("sign_default_alt", () -> new SignDefaultAltBlock());
	public static final RegistryObject<Block> SIGN_EXIT = REGISTRY.register("sign_exit", () -> new SignExitBlock());
	public static final RegistryObject<Block> SIGN_EXIT_ALT = REGISTRY.register("sign_exit_alt", () -> new SignExitAltBlock());
	public static final RegistryObject<Block> SIGN_ZONE_A = REGISTRY.register("sign_zone_a", () -> new SignZoneABlock());
	public static final RegistryObject<Block> SIGN_ZONE_B = REGISTRY.register("sign_zone_b", () -> new SignZoneBBlock());
	public static final RegistryObject<Block> SIGN_ZONE_C = REGISTRY.register("sign_zone_c", () -> new SignZoneCBlock());
	public static final RegistryObject<Block> SIGN_ZONE_D = REGISTRY.register("sign_zone_d", () -> new SignZoneDBlock());
	public static final RegistryObject<Block> SIGN_ZONE_A_ALT = REGISTRY.register("sign_zone_a_alt", () -> new SignZoneAAltBlock());
	public static final RegistryObject<Block> SIGN_ZONE_B_ALT = REGISTRY.register("sign_zone_b_alt", () -> new SignZoneBAltBlock());
	public static final RegistryObject<Block> SIGN_ZONE_C_ALT = REGISTRY.register("sign_zone_c_alt", () -> new SignZoneCAltBlock());
	public static final RegistryObject<Block> SIGN_ZONE_D_ALT = REGISTRY.register("sign_zone_d_alt", () -> new SignZoneDAltBlock());
	public static final RegistryObject<Block> SIGN_ZONE_AB = REGISTRY.register("sign_zone_ab", () -> new SignZoneABBlock());
	public static final RegistryObject<Block> SIGN_ZONE_CD = REGISTRY.register("sign_zone_cd", () -> new SignZoneCDBlock());
	public static final RegistryObject<Block> SIGN_ZONE_ABCD = REGISTRY.register("sign_zone_abcd", () -> new SignZoneABCDBlock());
	public static final RegistryObject<Block> SIGN_PLATFORM_1 = REGISTRY.register("sign_platform_1", () -> new SignPlatform1Block());
	public static final RegistryObject<Block> SIGN_PLATFORM_2 = REGISTRY.register("sign_platform_2", () -> new SignPlatform2Block());
	public static final RegistryObject<Block> SIGN_PLATFORM_3 = REGISTRY.register("sign_platform_3", () -> new SignPlatform3Block());
	public static final RegistryObject<Block> SIGN_PLATFORM_4 = REGISTRY.register("sign_platform_4", () -> new SignPlatform4Block());
	public static final RegistryObject<Block> SIGN_PLATFORM_5 = REGISTRY.register("sign_platform_5", () -> new SignPlatform5Block());
	public static final RegistryObject<Block> SIGN_PLATFORM_6 = REGISTRY.register("sign_platform_6", () -> new SignPlatform6Block());
	public static final RegistryObject<Block> SIGN_PLATFORM_7 = REGISTRY.register("sign_platform_7", () -> new SignPlatform7Block());
	public static final RegistryObject<Block> SIGN_PLATFORM_8 = REGISTRY.register("sign_platform_8", () -> new SignPlatform8Block());
	public static final RegistryObject<Block> SIGN_PLATFORM_9 = REGISTRY.register("sign_platform_9", () -> new SignPlatform9Block());
	public static final RegistryObject<Block> SIGN_PLATFORM_10 = REGISTRY.register("sign_platform_10", () -> new SignPlatform10Block());
	public static final RegistryObject<Block> SIGN_PLATFORM_11 = REGISTRY.register("sign_platform_11", () -> new SignPlatform11Block());
	public static final RegistryObject<Block> SIGN_PLATFORM_12 = REGISTRY.register("sign_platform_12", () -> new SignPlatform12Block());
	public static final RegistryObject<Block> SIGN_TICKETS = REGISTRY.register("sign_tickets", () -> new SignTicketsBlock());
	public static final RegistryObject<Block> SIGN_EXIT_BIG = REGISTRY.register("sign_exit_big", () -> new SignExitBigBlock());
	public static final RegistryObject<Block> SIGN_TICKETS_BIG = REGISTRY.register("sign_tickets_big", () -> new SignTicketsBigBlock());
	public static final RegistryObject<Block> SIGN_STAIRS_ASCENDING = REGISTRY.register("sign_stairs_ascending", () -> new SignStairsAscendingBlock());
	public static final RegistryObject<Block> SIGN_STAIRS_DESCENDING = REGISTRY.register("sign_stairs_descending", () -> new SignStairsDescendingBlock());
	public static final RegistryObject<Block> SIGN_RESTAURANT = REGISTRY.register("sign_restaurant", () -> new SignRestaurantBlock());
	public static final RegistryObject<Block> SIGN_CAFE = REGISTRY.register("sign_cafe", () -> new SignCafeBlock());
	public static final RegistryObject<Block> SIGN_NO_ENTRY = REGISTRY.register("sign_no_entry", () -> new SignNoEntryBlock());
	public static final RegistryObject<Block> SIGN_EXIT_ARROW = REGISTRY.register("sign_exit_arrow", () -> new SignExitArrowBlock());
	public static final RegistryObject<Block> SIGN_TICKETS_ARROW_1 = REGISTRY.register("sign_tickets_arrow_1", () -> new SignTicketsArrow1Block());
	public static final RegistryObject<Block> SIGN_TICKETS_ARROW_2 = REGISTRY.register("sign_tickets_arrow_2", () -> new SignTicketsArrow2Block());
	public static final RegistryObject<Block> SIGN_METRO_ENTRANCE = REGISTRY.register("sign_metro_entrance", () -> new SignMetroEntranceBlock());
	public static final RegistryObject<Block> SIGN_LINE_A_1 = REGISTRY.register("sign_line_a_1", () -> new SignLineA1Block());
	public static final RegistryObject<Block> SIGN_LINE_A_2 = REGISTRY.register("sign_line_a_2", () -> new SignLineA2Block());
	public static final RegistryObject<Block> SIGN_LINE_B_1 = REGISTRY.register("sign_line_b_1", () -> new SignLineB1Block());
	public static final RegistryObject<Block> SIGN_LINE_B_2 = REGISTRY.register("sign_line_b_2", () -> new SignLineB2Block());
}
